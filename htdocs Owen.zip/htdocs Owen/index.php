<?php
$names = $_POST['nama'];
$lahir = $_POST['date'];
$place = $_POST['tempat'];
$where = $_POST['alamat'];
$gender = $_POST['kelamin'];
$ast = $_POST['as'];
$uant = $_POST['uan'];
echo "<p>Terimakasih $names sudah mengisi form pendaftaran <p>";
echo "<p>Nama Lengkap: $names</p>";
echo "<p>Tanggal lahir: $lahir</p>";
echo "<p>tempat lahir: $place</p>";
echo "<p>Jenis Kelamin: $gender</p>";
echo "<p>Asal Sekolah: $ast</p>";
echo "<p>Nilai UAN: $uant</p>";
?>